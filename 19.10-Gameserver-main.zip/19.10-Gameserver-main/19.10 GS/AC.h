#pragma once 
#include "pch.h"

class AC
{
public:
    static void CheckUser(AFortPlayerControllerAthena*);
};