#pragma once
constexpr bool bDuos = false;
constexpr bool bLateGame = true;
constexpr bool bTournament = false;
constexpr bool bCreative = false;
constexpr bool bGameSessions = false;

constexpr bool bDev = true;

constexpr std::string IP = "91.208.92.200"; // eu: 185.206.149.110, nac: 23.134.168.92, nae: 172.93.104.100
constexpr std::string bRegion = "EU";
constexpr std::string eventId = "";

static int StartingCount = 0;
